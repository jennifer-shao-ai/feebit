// 圖片語法加寬器 — popup
// 規則：空白 +（可選的既有 width="750px" +空白）+ alt=  →  空白 + width="750px" alt=
// 空白開頭 = 只命中屬性形式的 alt，不會動到 data-alt / salt；既有 width 不重複加，可重跑。
const RE = /(\s)(?:width="750px"\s+)?alt=/gi;

const input = document.getElementById('input');
const output = document.getElementById('output');
const stat = document.getElementById('stat');
const copyBtn = document.getElementById('copyBtn');
const clearBtn = document.getElementById('clearBtn');
const toast = document.getElementById('toast');

function convert() {
  const src = input.value;
  if (!src.trim()) {
    output.value = '';
    stat.textContent = '';
    copyBtn.disabled = true;
    return;
  }
  let count = 0;
  output.value = src.replace(RE, (m, ws) => { count++; return ws + 'width="750px" alt='; });
  stat.innerHTML = count ? `已處理 <b>${count}</b> 個 alt` : '沒有找到 alt 屬性';
  copyBtn.disabled = !output.value;
}

input.addEventListener('input', convert);

clearBtn.addEventListener('click', () => {
  input.value = '';
  convert();
  input.focus();
});

copyBtn.addEventListener('click', async () => {
  if (!output.value) return;
  try {
    await navigator.clipboard.writeText(output.value);
  } catch (e) {
    output.select();
    document.execCommand('copy');
    window.getSelection().removeAllRanges();
  }
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 1500);
});

input.focus();
