# 圖片語法加寬器（Chrome 外掛）

貼上 HTML 語法，自動把每個 `alt=` 前面補上 `width="750px"`，一鍵複製貼回 SHOPLINE 商品描述。
點瀏覽器工具列圖示就用，不碰 SHOPLINE 編輯器，一定會動。

## 安裝（一次性）

1. Chrome 網址列輸入 `chrome://extensions`
2. 右上角打開「開發人員模式」
3. 點「載入未封裝項目」，選這個資料夾：
   `~/Documents/google chrome外掛安裝/SHOPLINE-alt加寬/`
4. 出現「圖片語法加寬器」→ 建議點工具列的拼圖圖示，把它「釘選」到工具列

> 已裝過舊版（右鍵版）的話，在 `chrome://extensions` 點這個外掛的「重新載入」即可更新成新版。

## 使用

1. SHOPLINE 後台商品描述 → 點 `<>`（原始碼）→ 全選複製裡面的 HTML
2. 點工具列的「圖片語法加寬器」圖示，跳出小視窗
3. 貼進上面的框 → 下面即時出改好的版本，顯示「已處理 N 個 alt」
4. 按「📋 一鍵複製」→ 回 SHOPLINE 原始碼框貼上覆蓋 → 關框存檔

## 規則

- `<img src="a.jpg" alt="圖1">` → `<img src="a.jpg" width="750px" alt="圖1">`
- 只比對屬性形式的 `alt`（前面有空白），不會動到 `data-alt` 這類字
- 已經有 `width="750px"` 的不會重複加，可以安心重跑

## 檔案

| 檔案 | 用途 |
|------|------|
| `manifest.json` | 外掛設定（MV3） |
| `popup.html` / `popup.js` | 小視窗介面與轉換邏輯 |
| `background.js` | v2.0 起停用，保留作版本紀錄，可刪 |

## 備註

- 純本機運作，不連任何伺服器，不需要網站權限
- 同一份邏輯的網頁版：https://jennifer-shao-ai.github.io/feebit/alt-width-replacer.html
